import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;

/**
 * Write a description of class Inspector here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Inspector extends Alien
{
    
    GumballMachine gb = null;
    public void inspect(Coin coin)
    {
        gb = getWorld().getObjects(GumballMachine.class).get(0);
        if ( coin.getClass() == FakeQuarter.class)
        {
            gb.setMessage("It is a fake coin",this.getX(),this.getY() );
        }
        else if ( coin.getClass() == Penny.class)
        {
            gb.setMessage("Penny not allowed",this.getX(),this.getY() );
        }
        else if (coin.getClass() == Quarter.class)
        {
            gb.setMessage("Quarter validated!!",this.getX(),this.getY() );
            Picker pickerChosen = getWorld().getObjects(RandomPicker.class).get(0);
            pickerChosen.select();
            
        }
    }
}