import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class insertButton extends Button
{
    private String name;
    GreenfootImage gi;
    public int hasQuarter = 0;
    GumballMachine gb = null;
    
 public insertButton (String name)
    {
        this.name = name;
    gi = new GreenfootImage(100,50);
        setImage(gi);
        gi.scale(150,50); 
        gi.clear();
        gi.setColor(Color.YELLOW);
        gi.fill();
        gi.setColor(Color.BLACK);
        gi.drawString(name ,50,50);
    
    }    
    
    
    
    public void act() 
    {
        gb = getWorld().getObjects(GumballMachine.class).get(0);
        if (Greenfoot.mouseMoved(this))
        {
            gi.scale(150,50);
            gi.setColor(Color.GRAY);
            gi.fill();
            gi.setColor(Color.BLACK);
            gi.drawString(name ,50,50);
        }
        
        if (Greenfoot.mouseClicked(this))
        {
            gi.scale(150,50);
            gi.setColor(Color.BLACK);
            gi.fill();
            gi.setColor(Color.WHITE);
            gi.drawString(name ,5,50);
            
            if (hasQuarter > 0)
            {
             gb.setMessage("Quarter already present.Crank !",gb.getX(),gb.getY());
            }
            else if (hasQuarter == 0)
            {
                gb.setMessage("Have Coin!",gb.getX(),gb.getY());
                hasQuarter += 1;
            }
        }
        
        
}
}