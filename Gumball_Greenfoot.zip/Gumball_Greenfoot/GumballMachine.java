import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class GumballMachine here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GumballMachine extends Actor
{
    Message m = new Message();
    boolean haveCoin = false;
    Coin c = null;
    Inspector i = null;
    
    
    public GumballMachine()
    {
        GreenfootImage image = getImage();
        image.scale(350,400);
    }
    
    public void setMessage( String msg, int x, int y)
    {
        int mouseX,mouseY ;
       /* MouseInfo mouse = Greenfoot.getMouseInfo();
        mouseX = mouse.getX();
        mouseY = mouse.getY();*/
        World world = getWorld();
        if (m.getWorld() != null)
        {
            world.removeObject (m);
        }
        
        world.addObject (m ,x,y) ;
        m.setText(msg);
    }
    
    public void act() 
    {
        
       /* if (Greenfoot.mousePressed(this)) {
            if (haveCoin == null)
                setMessage ("No Coin in slot !");
            else
                setMessage (" Crank turned ! "); 
            
        }*/
        
        if (getOneIntersectingObject(Coin.class) != null)
        {
            haveCoin = true;
            c = (Coin)getOneIntersectingObject(Coin.class);
            setMessage("Have Coin!! Crank It",this.getX(),this.getY());
            
            getWorld().removeObject(c);
            
        }
        
        
        if ( Greenfoot.mouseClicked(this))
        {
            if ( haveCoin)
            {
                
                setMessage ("Crank Turned! .Let the Inspector do the work.",this.getX(),this.getY());
                i = getWorld().getObjects(Inspector.class).get(0);
                i.inspect(c);            }    
            else
                setMessage (" Insert the coin first !",this.getX(),this.getY() );
        }
      
      }     
    }    

