import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Picker here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Picker extends Alien
{
    GumballMachine gb = null;
    
    public void select()
    {
            gb = getWorld().getObjects(GumballMachine.class).get(0);
            int w = Greenfoot.getRandomNumber(2);
            if ( w == 0)
            {   
                gb.setMessage("Random Picker!!",this.getX(),this.getY() );
                int whichPicker = Greenfoot.getRandomNumber(3);
                pick(whichPicker);
            }
            else
            {
                gb.setMessage("Green Picker !!",this.getX(),this.getY() );
                pick(0);
            }
        }
        
        public void pick ( int ballColor)
        {
            switch(ballColor)
            {
            case 0: //put green gum ball
                     GreenGumball objGreenGumball =  new GreenGumball();
                      objGreenGumball.getImage().scale(60,60);
                       getWorld().addObject(objGreenGumball, 500, 530);
                       gb.setMessage("Green Gumball!!",gb.getX(),gb.getY() );
                    break;
            case 1: //put red gum ball
                    RedGumball objRedGumball =  new RedGumball();
                      objRedGumball.getImage().scale(60,60);
                     getWorld().addObject(objRedGumball, 500, 530);
                     gb.setMessage("Red Gumball!!",gb.getX(),gb.getY() );
                    break;
            case 2: //put blue gum ball
                    BlueGumball objBlueGumball =  new BlueGumball();
                     objBlueGumball.getImage().scale(60,60);
                     getWorld().addObject(objBlueGumball, 500, 530);
                     gb.setMessage("Blue Gumball!!",gb.getX(),gb.getY() );
                    break;
                    
        }
        
        
    }
    public void act() 
    {
        // Add your action code here.
    }    
}
